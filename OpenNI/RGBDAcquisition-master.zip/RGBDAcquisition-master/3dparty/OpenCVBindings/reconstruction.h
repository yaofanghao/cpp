#ifndef RECONSTRUCTION_H_INCLUDED
#define RECONSTRUCTION_H_INCLUDED


int  reconstruct3D(const char * filenameLeft , unsigned int useOpenCVEstimator );

#endif // RECONSTRUCTION_H_INCLUDED
