#ifndef TOOLS_H_INCLUDED
#define TOOLS_H_INCLUDED

void clear_line();

#endif // TOOLS_H_INCLUDED
