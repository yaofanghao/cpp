#ifndef TOOLS_H_INCLUDED
#define TOOLS_H_INCLUDED

#ifdef __cplusplus
extern "C"
{
#endif

unsigned long AmmClient_GetTickCountMicrosecondsInternal();

unsigned long AmmClient_GetTickCountMillisecondsInternal();


#ifdef __cplusplus
}
#endif

#endif // TOOLS_H_INCLUDED
