#!/bin/bash
cd frames
rm *.pnm
cd ..
exit 0
