#!/bin/bash
 
tar cvfjh "./compressed-$1.tar.bz2" $1/ 
exit 0
