#!/bin/bash
tar xvjf  "$1.tar.bz2"
exit 0
