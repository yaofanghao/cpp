#!/bin/bash
sudo cat kinect >> /etc/udev/rules.d/55-primesense-usb.rules

exit 0
