#!/bin/bash



apt-get install opencl-headers

exit 0
