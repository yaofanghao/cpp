/** @file image_proc.h
 *  @brief A little image processing part of the bigger tools/ImageOperations/imageOps.c , provided here to simplify linking
 *  @author Ammar Qammaz (AmmarkoV)
 */

#ifndef TRAJECTORYPARSER_H_INCLUDED
#define TRAJECTORYPARSER_H_INCLUDED
