#ifndef TEXTURE_LOADER_H_INCLUDED
#define TEXTURE_LOADER_H_INCLUDED

GLuint loadTexture(int type,char * directory ,char *fname);

#endif // TEXTURE_LOADER_H_INCLUDED
