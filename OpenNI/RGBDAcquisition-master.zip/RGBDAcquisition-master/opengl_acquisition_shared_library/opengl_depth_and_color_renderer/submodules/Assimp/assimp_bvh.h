#ifndef ASSIMP_BVH_H_INCLUDED
#define ASSIMP_BVH_H_INCLUDED

int doBVHConversion(char * sourceBVH);

#endif // ASSIMP_BVH_H_INCLUDED
