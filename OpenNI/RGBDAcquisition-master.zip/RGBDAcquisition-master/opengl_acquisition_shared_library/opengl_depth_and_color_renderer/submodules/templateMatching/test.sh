#!/bin/bash
./templateMatching color.pnm dragon.png  
exit 0
