// OpenNI2Project.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
// General headers
#include <stdio.h>
// OpenNI headers
#include <OpenNI.h> 
using namespace openni;

int _tmain(int argc, _TCHAR* argv[])
{
	return 0;
}

