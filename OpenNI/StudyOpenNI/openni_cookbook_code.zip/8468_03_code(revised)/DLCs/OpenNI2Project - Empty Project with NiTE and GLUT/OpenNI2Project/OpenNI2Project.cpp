// OpenNI2Project.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
// General headers
#include <stdio.h>
// OpenNI2 headers
#include <OpenNI.h> 
using namespace openni;
// NITE2 headers
#include <NiTE.h>
// GLUT headers
#include <gl/glut.h>

int _tmain(int argc, _TCHAR* argv[])
{
	return 0;
}

